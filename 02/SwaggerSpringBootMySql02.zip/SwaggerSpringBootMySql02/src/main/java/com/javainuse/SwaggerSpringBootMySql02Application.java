package com.javainuse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwaggerSpringBootMySql02Application {

	public static void main(String[] args) {
		SpringApplication.run(SwaggerSpringBootMySql02Application.class, args);
	}

}
