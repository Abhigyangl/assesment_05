package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwaggerSpringBootMySql02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
